#! /bin/bash

wget -N --load-cookies ~/.urs_cookies --save-cookies ~/.urs_cookies --auth-no-challenge=on --keep-session-cookies --content-disposition -i /media/juli/Elements/GPM3IMERGHHE/wget2_nc4_25082014-07022015.txt
wget -N --load-cookies ~/.urs_cookies --save-cookies ~/.urs_cookies --auth-no-challenge=on --keep-session-cookies --content-disposition -i /media/juli/Elements/GPM3IMERGHHE/wget3_nc4_07022015-23072015.txt
wget -N --load-cookies ~/.urs_cookies --save-cookies ~/.urs_cookies --auth-no-challenge=on --keep-session-cookies --content-disposition -i /media/juli/Elements/GPM3IMERGHHE/wget4_nc4_23072015-05012016.txt
wget -N --load-cookies ~/.urs_cookies --save-cookies ~/.urs_cookies --auth-no-challenge=on --keep-session-cookies --content-disposition -i /media/juli/Elements/GPM3IMERGHHE/wget5_nc4_05012016-19062016.txt
wget -N --load-cookies ~/.urs_cookies --save-cookies ~/.urs_cookies --auth-no-challenge=on --keep-session-cookies --content-disposition -i /media/juli/Elements/GPM3IMERGHHE/wget6_nc4_19062016-02122016.txt
wget -N --load-cookies ~/.urs_cookies --save-cookies ~/.urs_cookies --auth-no-challenge=on --keep-session-cookies --content-disposition -i /media/juli/Elements/GPM3IMERGHHE/wget7_nc4_02122016-17052017.txt
wget -N --load-cookies ~/.urs_cookies --save-cookies ~/.urs_cookies --auth-no-challenge=on --keep-session-cookies --content-disposition -i /media/juli/Elements/GPM3IMERGHHE/wget8_nc4_17052017-30102017.txt
wget -N --load-cookies ~/.urs_cookies --save-cookies ~/.urs_cookies --auth-no-challenge=on --keep-session-cookies --content-disposition -i /media/juli/Elements/GPM3IMERGHHE/wget9_nc4_30102017_28122017.txt
wget -N --load-cookies ~/.urs_cookies --save-cookies ~/.urs_cookies --auth-no-challenge=on --keep-session-cookies --content-disposition -i /media/juli/Elements/GPM3IMERGHHE/wget10_nc4_28122017-12062018.txt
wget -N --load-cookies ~/.urs_cookies --save-cookies ~/.urs_cookies --auth-no-challenge=on --keep-session-cookies --content-disposition -i /media/juli/Elements/GPM3IMERGHHE/wget11_nc4_12062018-25112018.txt 
wget -N --load-cookies ~/.urs_cookies --save-cookies ~/.urs_cookies --auth-no-challenge=on --keep-session-cookies --content-disposition -i /media/juli/Elements/GPM3IMERGHHE/wget12_nc4_25112018-30012019.txt
